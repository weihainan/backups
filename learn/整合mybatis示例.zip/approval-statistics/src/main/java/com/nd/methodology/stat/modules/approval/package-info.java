/**
 * 案子审核数据，包括节点，审核结果，审核人，审核时间，原因，亮点，大小红花，大小错误等等信息
 * 数据由审案子工具主动推过来
 * @author yanguanyu(290536)
 * @since 0.1 created on 2017/6/21.
 */
package com.nd.methodology.stat.modules.approval;