package com.nd.methodology.stat.config;

import com.nd.gaea.rest.config.WafWebSecurityConfigurerAdapter;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.servlet.configuration.EnableWebMvcSecurity;

/**
 * @author yanguanyu(290536)
 * @since 0.1 created on 2016/10/27.
 */
@Configuration
@EnableWebMvcSecurity
public class SecurityConfig extends WafWebSecurityConfigurerAdapter {

    @Override
    public void configure(WebSecurity web) throws Exception {
        String[] ignores = new String[]{};
        web.ignoring().antMatchers(ignores);
    }

    @Override
    protected void onConfigure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .anyRequest().authenticated();
    }
}
