package com.nd.methodology.stat.internal.support;

import com.nd.gaea.rest.security.authens.UserInfo;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * @author yanguanyu(290536)
 * @since 0.1 created on 2016/12/20.
 */
@Component
public class Context implements ApplicationContextAware {
    private static ApplicationContext applicationContext;

    private final static String KEY_USER_INFO = "user_info"; //当前用户信息

    private Context(){}

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        initContextHolder(applicationContext);
    }

    private static void initContextHolder(ApplicationContext context) {
        Context.applicationContext = context;
    }

    public static ApplicationContext getApplicatinContext() {
        return applicationContext;
    }

    public HttpServletRequest getRequest() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        return attributes.getRequest();
    }

    public static Object getBean(String name) {
        return applicationContext.getBean(name);
    }

    public static <T> T getBean(String name, Class<T> requiredType) {
        return applicationContext.getBean(name, requiredType);
    }

    public static <T> T getBean(Class<T> requiredType) {
        return applicationContext.getBean(requiredType);
    }

    public void setUserInfo(UserInfo userInfo) {
        getRequest().setAttribute(KEY_USER_INFO, userInfo);
    }

    public UserInfo getUserInfo() {
        return (UserInfo) getRequest().getAttribute(KEY_USER_INFO);
    }

    public String getUserId() {
        return getUserInfo() == null? null : getUserInfo().getUserId();
    }

    public String getUserName() {
        if (getUserInfo() == null) return null;
        Object realName = getUserInfo().getOrgExinfo().get("real_name");
        if (realName == null) {
            return getUserInfo().getUserName();
        }
        return (String) realName;
    }
}
