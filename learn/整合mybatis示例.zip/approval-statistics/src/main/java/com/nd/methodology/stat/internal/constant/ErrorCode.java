package com.nd.methodology.stat.internal.constant;

import com.nd.methodology.stat.internal.exception.IErrorCode;
import org.springframework.http.HttpStatus;

public enum ErrorCode implements IErrorCode {


    ;


    private HttpStatus httpStatus;
    private String code;
    private String message;
    public static final String PREFIX = "APPROVAL_STAT/";

    ErrorCode(HttpStatus httpStatus, String code, String message) {
        setHttpStatus(httpStatus);
        setCode(code);
        setMessage(message);
    }

    @Override
    public HttpStatus getHttpStatus() {
        return this.httpStatus;
    }

    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    @Override
    public String getCode() {
        return PREFIX + this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
