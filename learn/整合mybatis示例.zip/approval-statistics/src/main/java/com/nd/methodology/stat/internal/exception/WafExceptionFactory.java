package com.nd.methodology.stat.internal.exception;

import com.nd.gaea.WafException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;


public class WafExceptionFactory {

    private WafExceptionFactory() {
    }

    /**
     * code 为 "WAF/INTERNAL_SERVER_ERROR";
     * HttpStatus 为 HttpStatus.INTERNAL_SERVER_ERROR (500);
     * message 为 message
     *
     * @param message 错误消息描述
     */
    public static WafException of(String message, String... args) {
        return of("WAF/INTERNAL_SERVER_ERROR", message, HttpStatus.INTERNAL_SERVER_ERROR, null);
    }

    /**
     * code 为 "WAF/INTERNAL_SERVER_ERROR";
     * HttpStatus 为 HttpStatus.INTERNAL_SERVER_ERROR (500);
     * message 为 message
     *
     * @param message 错误消息描述
     */
    public static WafException of(String message, Throwable cause) {
        return of("WAF/INTERNAL_SERVER_ERROR", message, HttpStatus.INTERNAL_SERVER_ERROR, cause);
    }

    public static WafException of(String message, IErrorCode errorCode) {
        return of(errorCode.getCode(), message, errorCode.getHttpStatus(), null);
    }

    public static WafException of(IErrorCode errorCode) {
        return of(errorCode.getCode(), errorCode.getMessage(), errorCode.getHttpStatus(), null);
    }

    public static WafException of(String code, String message, HttpStatus status) {
        return of(code, message, status, null);
    }

    public static WafException of(String message, IErrorCode errorCode, Throwable cause) {
        if (StringUtils.isBlank(message)) {
            message = errorCode.getMessage();
        }
        return of(errorCode.getCode(), message, errorCode.getHttpStatus(), cause);
    }

    public static WafException of(IErrorCode errorCode, Throwable cause) {
        return of(errorCode.getCode(), errorCode.getMessage(), errorCode.getHttpStatus(), cause);
    }

    public static WafException of(String code, String message, HttpStatus status, Throwable cause) {
        return new WafException(code, message, status, cause);
    }

}
