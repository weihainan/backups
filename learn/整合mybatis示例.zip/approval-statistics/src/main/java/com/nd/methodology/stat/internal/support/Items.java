package com.nd.methodology.stat.internal.support;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;

import java.util.Collection;

/**
 * @author yanguanyu(290536)
 * @since 0.1 created on 2016/10/31.
 */
public class Items<T> {

    private Collection<T> items;

    public static <T> Items<T> of(Collection<T> list) {
        Items<T> items = new Items<>();
        items.setItems(list);
        return items;
    }

    public static <T, S> Items<T> of(Collection<S> sList, Function<? super S, T> function) {
        Items<T> items = new Items<>();
        items.setItems(Collections2.transform(sList, function));
        return items;
    }


    public Collection<T> getItems() {
        return items;
    }

    public void setItems(Collection<T> items) {
        this.items = items;
    }
}
