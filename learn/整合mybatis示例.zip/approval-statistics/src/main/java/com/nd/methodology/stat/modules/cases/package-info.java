/**
 * 方法论案子数据，包含案子所属项目，花费时间等等
 * 需要主要到方法论服务端拉取数据
 * @author yanguanyu(290536)
 * @since 0.1 created on 2017/6/21.
 */
package com.nd.methodology.stat.modules.cases;