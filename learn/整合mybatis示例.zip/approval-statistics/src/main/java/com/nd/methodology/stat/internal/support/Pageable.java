package com.nd.methodology.stat.internal.support;

/**
 * @author yanguanyu(290536)
 * @since 0.1 created on 2016/11/3.
 */
public class Pageable {
    private int offset;
    private int limit;

    public Pageable() {}

    public Pageable(int offset, int limit) {
        setOffset(offset);
        setLimit(limit);
    }

    public static Pageable of(int offset, int limit) {
        return new Pageable(offset, limit);
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }
}
