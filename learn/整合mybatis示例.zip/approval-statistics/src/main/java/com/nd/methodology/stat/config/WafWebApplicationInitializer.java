package com.nd.methodology.stat.config;

import com.nd.gaea.rest.AbstractWafWebApplicationInitializer;

/**
 * @author yanguanyu(290536)
 * @since 0.1 created on 2016/10/27.
 */
public class WafWebApplicationInitializer extends AbstractWafWebApplicationInitializer {

    @Override
    protected Class<?>[] getServletConfigClasses() {
        return new Class<?>[]{
            WebConfig.class, MyBatisConfig.class
        };
    }

    @Override
    protected Class<?>[] getRootConfigClasses() {
        return new Class[]{SecurityConfig.class};
    }
}
