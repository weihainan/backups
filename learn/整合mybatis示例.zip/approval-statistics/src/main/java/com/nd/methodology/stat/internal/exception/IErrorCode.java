package com.nd.methodology.stat.internal.exception;

import org.springframework.http.HttpStatus;

/**
 * Created by Zhang Jinlong(150429) on 2016/4/28.
 */
public interface IErrorCode {

    HttpStatus getHttpStatus();

    String getCode();

    String getMessage();
}
