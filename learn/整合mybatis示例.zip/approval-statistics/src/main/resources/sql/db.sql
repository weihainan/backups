--
-- `test`
--
CREATE TABLE IF NOT EXISTS `test` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键，类型代码',

) ENGINE=InnoDB DEFAULT CHARSET=utf8;

